# 💬💭 속마음 번역기 (Mind Translator)

상대방이 한 말 속에 숨겨진 진짜 의도와 심리를 Google Gemini API를 활용해 번역해주는 서버리스 웹 애플리케이션입니다.

---

## 🛠 기술 스택
- **Frontend**: HTML5, Tailwind CSS (CDN), Vanilla JavaScript
- **Backend (Serverless)**: Node.js, Vercel Serverless Functions (`api/generate.js`)
- **AI Engine**: Google Gemini API (`gemini-2.5-flash`)
- **Deployment**: Vercel

---

## 📁 프로젝트 구조

```
mind-translator/
├── index.html        # 메인 웹 UI
├── api/
│   └── generate.js   # Gemini API 호출 서버리스 엔드포인트
├── package.json      # 프로젝트 의존성 설정
├── .gitignore        # Git 제외 설정
├── LICENSE           # MIT 라이선스
└── README.md         # 프로젝트 안내 파일
```

---

## 🚀 Vercel 배포 방법

### 1. Vercel CLI로 배포하기
1. 프로젝트 폴더로 이동합니다:
   ```bash
   cd mind-translator
   ```
2. Vercel CLI 설치 및 로그인:
   ```bash
   npm i -g vercel
   vercel login
   ```
3. 프로젝트 배포:
   ```bash
   vercel
   ```

### 2. GitHub 웹 대시보드로 배포하기
1. 본 프로젝트 코드를 GitHub 저장소(Repository)에 푸시합니다.
2. [Vercel Dashboard](https://vercel.com/dashboard)에 접속하여 **Add New > Project**를 선택합니다.
3. 해당 GitHub 저장소를 연결합니다.

---

## 🔑 환경변수(Environment Variables) 설정

Vercel 프로젝트 대시보드의 **Settings > Environment Variables** 메뉴에서 다음 환경변수를 반드시 추가해야 합니다:

| Key | Value |
| --- | --- |
| `GEMINI_API_KEY` | Google AI Studio에서 발급받은 Gemini API Key |

> 💡 **API Key 발급 방법**: [Google AI Studio](https://aistudio.google.com/)에서 무료 API 키를 생성할 수 있습니다.

---

## 💻 로컬 개발 환경 실행

1. 의존성 설치:
   ```bash
   npm install
   ```
2. 로컬 환경변수 설정 (`.env.local` 파일 생성):
   ```env
   GEMINI_API_KEY=your_gemini_api_key_here
   ```
3. Vercel Dev 서버 실행:
   ```bash
   npx vercel dev
   ```
4. 브라우저에서 `http://localhost:3000` 접속

---

## 📄 라이선스
MIT License
