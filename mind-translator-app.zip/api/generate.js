const { GoogleGenerativeAI } = require('@google/generative-ai');

module.exports = async function handler(req, res) {
  // Allow only POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const { text } = req.body || {};

  if (!text) {
    return res.status(400).json({ error: '번역할 텍스트를 입력해 주세요.' });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'GEMINI_API_KEY 환경변수가 설정되지 않았습니다.' });
  }

  try {
    const genAI = new GoogleGenerativeAI(apiKey);
    // Use latest Gemini 2.5 Flash model
    const model = genAI.getGenerativeModel({ model: 'gemini-2.5-flash' });

    const prompt = `
너는 사람들의 대화 속 숨겨진 심리와 속마음을 파악하는 전문가이자 친근한 심리 상담가야.
사용자가 입력한 상대방의 말: "${text}"

위 말을 바탕으로 아래 3가지 요소를 나누어 자연스럽고 흥미롭게 번역해줘:

1. 💡 **겉으로 한 말의 진짜 의미 (속마음 번역)**
   (상대방이 돌려서 표현했거나 숨기려 했던 직관적인 진짜 속마음 한 줄)

2. 🧠 **상대방이 이 말을 한 심리 및 배경**
   (왜 이런 식으로 말했을지, 상대방의 마음속 불안/기대/관심/서운함 등 심리 상태 설명)

3. 💡 **추천 대처법 (센스 있는 답장 예시)**
   (이 말을 들었을 때 분위기를 살리거나 상대방 마음을 사로잡을 수 있는 추천 답변 1~2개)

답변은 한국어로 위트 있고 공감되게 작성해줘.
`;

    const result = await model.generateContent(prompt);
    const responseText = result.response.text();

    return res.status(200).json({ result: responseText });
  } catch (error) {
    console.error('Gemini API Error:', error);
    return res.status(500).json({ error: 'Gemini API 호출 중 오류가 발생했습니다.' });
  }
};
